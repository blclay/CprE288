
/**
 * main.c
 */

#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "cyBot_uart.h"
#include "movement.h"

int main(void)
{
    oi_t *sensor_data = oi_alloc();
    oi_free(sensor_data);
    oi_init(sensor_data);
    turn_clockwise(sensor_data, 180);
    oi_free(sensor_data);

    return 0;
}
