#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "cyBot_uart.h"
#include "movement.h"


 void move_forward(oi_t *sensor, int centimeters)
{
     double sDistance = 9.58*centimeters;
     double sum = 0;
     oi_setWheels(500, 500); // move forward; full speed
     while (sum < sDistance)
     {
         oi_update(sensor);
         sum += sensor->distance;
     }
     oi_setWheels(0, 0);
}


void turn_clockwise(oi_t *sensor, int degrees)
{
    if (degrees > 360)
        {
            degrees = degrees % 360;
        }
    double sum = 0;
    oi_setWheels(-100, 100);
    while (sum < 100)
    {
            oi_update(sensor);
            sum += sensor->angle;
    }
    oi_setWheels(0, 0);


}

void turn_counterClockwise(oi_t *sensor, int degrees)
{

    if (degrees > 360)
    {
        degrees = degrees % 360;
    }
    double sum = 0;
    oi_setWheels(100, -100);
    while (sum < 100)
        {
            oi_update(sensor);
            sum += sensor->angle;
        }
    oi_setWheels(0, 0);


}

void move_backward(oi_t *sensor, int centimeters)
{
    double sum =0;
    double sDistance = 9.55*centimeters;
    oi_setWheels(-500, -500);
    while (sum < sDistance)
    {
        // move backwards
        oi_update(sensor);
        sum += sensor->distance;
    }
    oi_setWheels(0, 0);

}
