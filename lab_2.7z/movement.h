#ifndef MOVEMENT
#define MOVEMENT

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <inc/tm4c123gh6pm.h>

void move_forward(oi_t *sensor, int centimeters);


void turn_clockwise(oi_t *sensor, int degrees);

void turn_counterClockwise(oi_t *sensor, int degrees);

void move_backward(oi_t *sensor, int centimeters);


#endif
