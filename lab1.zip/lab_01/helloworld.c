/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Describtion: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"



int main(void){
    char str[ ] = "                    M!";
    char disp[21];
    int i, j;
    int str_len = 54;
    int disp_len = 20;
    timer_init();
    lcd_init();

    while(1)
    {
    for(i=0; i<str_len; i++)
    {
        str[str_len] = str[0];
        for(j=0; j<str_len; j++)
        {
            str[j] = str[j+1];
        }
        str[str_len] = '\0';
        strncpy(disp, str, disp_len);
        disp[disp_len] = '\0';

        lcd_printf(disp);
        timer_waitMillis(300);
    }
    }
    return 0;
}
